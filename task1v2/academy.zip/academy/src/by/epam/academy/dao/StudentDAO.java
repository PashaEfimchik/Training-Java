package by.epam.academy.dao;

public class StudentDAO implements DAO<T>{

  @Override
  public T create() {
    return null;
  }

  @Override
  public T update() {
    return null;
  }
}
