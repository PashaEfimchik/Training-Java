package by.epam.academy.dao;

public interface DAO<T> {
T create();
T update();
//delete
//  read
}
