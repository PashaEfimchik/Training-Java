package by.epam.academy.service;

public class StudentService {
create(T entity){
  dao.create(T entity)
}
}
