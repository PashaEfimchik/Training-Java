package by.epam.academy.view;

public class Menu {

}
