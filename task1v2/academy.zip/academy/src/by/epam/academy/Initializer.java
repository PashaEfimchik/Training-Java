package by.epam.academy;

public class Initializer {

  public static void init() {
  }
}
