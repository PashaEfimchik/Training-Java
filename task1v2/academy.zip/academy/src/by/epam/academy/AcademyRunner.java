package by.epam.academy;

public class AcademyRunner {

  public static void main(String[] args) {
    Menu.run();

    Initializer.init();
  }
}
